Griduino Audio Files
----------
This folder contains an American male voice for 26 letters and 10 numbers.

Copyright (C) 2021, Barry Hansen, barry@electromagneticsoftware.com

Voice Credit
----------
The voice is Barry Hansen of Seattle, Washington, USA.

This was recorded on the built-in microphone of a Microsoft Studio desktop computer and processed by Audacity 3.0 and exported as:

* Type: WAV (Microsoft)
* Sample rate: 16 kHz monophonic
* Encoding: Signed 16-bit PCM

Original Source Files
----------
https://github.com/barry-ha/Audio_QSPI

License
----------
GNU General Public License 3.0, https://www.gnu.org/licenses/gpl-3.0.en.html

This audio is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with these files. If not, see <https://www.gnu.org/licenses/>.

